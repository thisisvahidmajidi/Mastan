<?php /* Silence is golden. */
